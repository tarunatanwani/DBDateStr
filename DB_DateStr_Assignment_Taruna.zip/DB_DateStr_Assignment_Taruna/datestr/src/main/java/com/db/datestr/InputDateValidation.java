package com.db.datestr;


import java.io.IOException;


import org.apache.commons.validator.GenericValidator;

public class InputDateValidation implements InputDateValidationInterface {
	YearInterface yearObj = new Year();
	DateInterface dateObj = new Date();
	MonthInterface monthObj = new Month();
	TimeInterface timeObj = new Time();
	DayInterface dayInterface = new Day();
	
	 String inputdate="";
	 String date = "";
     String month = "";
     String year = "";
     String date_month_year[] = new String[2];
	
	public boolean inputvalidatedate(String inputdate) throws IOException {			
	    boolean flag = GenericValidator.isDate(inputdate, "dd-mm-yyyy hh:mm:ss a", false);	    
	    return flag;
	}
	
	public void printvalidateddate(String inputdate) throws Exception {		
    	String strarr[] = inputdate.split(" "); 
    	String datemonthyear = strarr[0];
    	date_month_year = datemonthyear.split("-");
    	date = date_month_year[0];
    	month = date_month_year[1];
    	year = date_month_year[2];
    	
    	String printdate = dateObj.printDate(date);        	
    	String printmonth = monthObj.printMonth(month);        	
    	String printyear = yearObj.printYear(year);
    	
    	String time = strarr[1];
    	String hour_min_sec[] = time.split(":");
    	String hour = hour_min_sec[0];
    	String min = hour_min_sec[1];
    	String sec = hour_min_sec[2];
    	
    	String meridian = inputdate.substring(inputdate.length()-2);
    	if (meridian.equalsIgnoreCase("AM")) {
    		meridian = "Morning";
    	}
    	else {
    		meridian = "Evening";
    	}
    	String printhour = timeObj.printHour(hour);
    	String printmin = timeObj.printMin(min);
    	String printsec = timeObj.printSec(sec);
    	
    	
    	System.out.println("Valid Date : " + printdate + " - "+printmonth+ " - "+printyear);
    	System.out.println("Valid Time : "+ printhour + " Hours "+ printmin + " Minutes "+ printsec+" Seconds" + " - "+meridian);
		
    
	}
	
	public void printDay () throws Exception {
		  String Day = dayInterface.getDay(date, month, year.substring(2,4), year.substring(0, 2));
	      System.out.println("Day of week : "+Day);      
	}
	
	
}
