package com.db.datestr;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class DateStrApplication {   

    public static void main(String[] args) throws Exception {    	
    	
    	InputDateValidationInterface inputdatevalidation = new InputDateValidation(); 
    	String inputdate="";		
		  InputStreamReader r=new InputStreamReader(System.in); BufferedReader br=new
		  BufferedReader(r);       
		  
		  System.out.println("Please enter the date in format : dd-mm-yyyy hh:mm:ss AM/PM" ); 
		  inputdate = br.readLine(); 	  
		 
        boolean flag = inputdatevalidation.inputvalidatedate(inputdate);
       
        
        if (flag) {        	
        	inputdatevalidation.printvalidateddate(inputdate);
        	inputdatevalidation.printDay();        	
         }
        else {
        	System.out.println("Invalid Date. Please enter valid date");
        }              
        
        
    }

	

}