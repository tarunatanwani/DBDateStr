package com.db.datestr;

import java.util.HashMap;

public class Date implements DateInterface {	 
	
	public String printDate(String date) throws Exception {
		Integer dateInt = Integer.valueOf(date);
		String mapval = "";
		String printdate = "";
		HashMap <Integer, String> map = new HashMap<Integer, String>();
		map.put(1, "st");
		map.put(21, "st");
		map.put(31, "st");
		map.put(2, "nd");
		map.put(3,"rd");
		
		
		if(map.containsKey(dateInt)) {				
				mapval = map.get(dateInt);				
		}
		else {
			mapval = "th";
		}
		 printdate = dateInt+mapval;
		 return printdate;
	}

	

}
