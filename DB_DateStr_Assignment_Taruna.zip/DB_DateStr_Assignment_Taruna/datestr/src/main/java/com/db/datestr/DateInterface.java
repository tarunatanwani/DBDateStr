package com.db.datestr;

public interface DateInterface {	
	public String printDate(String date) throws Exception;
}
