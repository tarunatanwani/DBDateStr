package com.db.datestr;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class PropertyValue {
	public static String getYearValue(String num) throws IOException {
		FileReader reader=new FileReader("resources\\application_year.properties");
		Properties p=new Properties();
		p.load(reader);
		String value = p.getProperty(num);
		return value;
	}
	
	public static String getMonthValue(String num) throws IOException {
		FileReader reader=new FileReader("resources\\application_month.properties");
		Properties p=new Properties();
		p.load(reader);
		String value = p.getProperty(num);
		return value;
	}
	
	public static String getTimeValue(String num) throws IOException {
		FileReader reader=new FileReader("resources\\application_time.properties");
		Properties p=new Properties();
		p.load(reader);
		String value = p.getProperty(num);
		return value;
	}
	
	
}


