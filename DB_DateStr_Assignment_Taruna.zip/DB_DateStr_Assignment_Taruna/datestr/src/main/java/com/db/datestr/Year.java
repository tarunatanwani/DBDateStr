package com.db.datestr;

public class Year implements YearInterface {

	public String getYear(String InputDate) {
		return InputDate;
		
	}

	public   String printYear(String year) throws Exception {			
			String year_part1 = "";
			String year_part2 = "";
			String year_part3 = "";
			String year_part4 = "";
			if(Integer.valueOf(year.substring(0,2))>=20){
				year_part1 = PropertyValue.getYearValue(year.substring(0,1)+"0");
				if(year_part1==null) {
					year_part1 = "";
				}
				year_part2 = PropertyValue.getYearValue(year.substring(1,2));
				if(year_part2==null) {
					year_part2 = "";
				}
			}
			else {
				year_part1= PropertyValue.getYearValue(year.substring(0,2));
			}
					
			if(Integer.valueOf(year.substring(2,4))>=20){
				year_part3 = PropertyValue.getYearValue(year.substring(2,3)+"0");
				if(year_part3==null) {
					year_part3 = "";
				}
				year_part4 = PropertyValue.getYearValue(year.substring(3,4));
				if(year_part4==null) {
					year_part4 = "";
				}
			}
			else {
				year_part3= PropertyValue.getYearValue(year.substring(2,4));
			}		
		
	        
	        String printyear = year_part1 + " "+year_part2 + " "+year_part3 + " "+year_part4;
	        return printyear;
	}

}


