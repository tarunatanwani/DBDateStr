package com.db.datestr;

public interface MonthInterface {	
	public String printMonth(String year) throws Exception;
}
