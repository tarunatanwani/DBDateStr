package com.db.datestr;

public class Day implements DayInterface {
	 
	
	public String getDay(String strk, String strm, String strD, String strC) {
		// TODO Auto-generated method stub
		
		/*
		 *  k is  the day of the month.
			m is the month number.
			D is the last two digits of the year.
			C is the first two digits of the year.
			F is the Day
			F=k+ [(13*m-1)/5] +D+ [D/4] +[C/4]-2*C which needs to be divided by 7
		 */
		
		String[] weekdays = new String[7];
		weekdays[0] = "Sunday";
		weekdays[1] = "Monday";
		weekdays[2] = "Tuesday";
		weekdays[3] = "Wednesday";
		weekdays[4] = "Thursday";
		weekdays[5] = "Friday";
		weekdays[6] = "Saturday";
		
		int k = Integer.valueOf(strk);
		int m = Integer.valueOf(strm)-2;  //March is considered as first month as per the Zeller’s rule
		int D = Integer.valueOf(strD);
		int C = Integer.valueOf(strC);
		
		int F=k + ((13*m-1)/5) +D+ (D/4) +(C/4)-2*C ;
				
		F=F%7;
		
				
		if(F<0) {
			F+=7;
		}
		
		return weekdays[F];
	}

}
