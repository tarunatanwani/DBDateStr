package com.db.datestr;

public interface TimeInterface {
	
	public String printHour(String hour) throws Exception;
	public String printMin(String min) throws Exception;
	public String printSec(String sec) throws Exception;
}
