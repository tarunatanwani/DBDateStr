package com.db.datestr;

public class Month implements MonthInterface {

	/*
	 * public String getMonth(String InputDate) { // TODO Auto-generated method stub
	 * return null; }
	 */

	public String printMonth(String month) throws Exception {
		 	String printmonth = PropertyValue.getMonthValue(month);	        
	        return printmonth;
	}

}
