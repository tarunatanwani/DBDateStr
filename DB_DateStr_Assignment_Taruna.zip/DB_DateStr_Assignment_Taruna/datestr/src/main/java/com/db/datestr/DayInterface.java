package com.db.datestr;

public interface DayInterface {
	public String getDay(String k , String m, String D, String C);

		
		/*
		 *  k is  the day of the month.
			m is the month number.
			D is the last two digits of the year.
			C is the first two digits of the year.
			F is the Day
			F=k+ [(13*m-1)/5] +D+ [D/4] +[C/4]-2*C which needs to be divided by 7
		 */
}
