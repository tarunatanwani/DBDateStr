package com.db.datestr;

import java.io.IOException;

public interface InputDateValidationInterface {
	public boolean inputvalidatedate(String inputdate) throws IOException;
	public void printvalidateddate (String inputdate) throws Exception ;
	public void printDay() throws Exception;	
	
}
