package com.db.datestr;

public interface YearInterface {
	public  String getYear(String InputDate);
	public String printYear(String year) throws Exception;
}
