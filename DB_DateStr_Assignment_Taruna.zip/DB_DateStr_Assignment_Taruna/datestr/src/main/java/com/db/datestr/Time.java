package com.db.datestr;

import java.io.IOException;

public class Time implements TimeInterface {

	
	

	public String printHour(String hour) throws IOException {
		String printhour = PropertyValue.getTimeValue(hour);
		return printhour;
	}

	public String printMin(String min) throws IOException {
		String printmin_part1="";
		String printmin_part2 ="";
		if(Integer.valueOf(min)>=20){
			printmin_part1= PropertyValue.getTimeValue(min.substring(0,1)+"0");
			if(printmin_part1==null) {
				printmin_part1 = "";
			}
			printmin_part2 = PropertyValue.getTimeValue(min.substring(1,2));
			if(printmin_part2==null) {
				printmin_part2 = "";
			}
		}
		else {
			printmin_part1= PropertyValue.getTimeValue(min.substring(0,2));
		}
		
		String printmin = printmin_part1+ " " +printmin_part2 ;
		return printmin;
	}

	public String printSec(String sec) throws IOException {
		String printsec_part1 = "";
		String printsec_part2 = "";
		
		if(Integer.valueOf(sec)>=20){
			printsec_part1 = PropertyValue.getTimeValue(sec.substring(0,1)+"0");
			if(printsec_part1==null) {
				printsec_part1 = "";
			}
			printsec_part2 = PropertyValue.getTimeValue(sec.substring(1,2));
			if(printsec_part2==null) {
				printsec_part2 = "";
			}
		}
		else {
			printsec_part1= PropertyValue.getTimeValue(sec.substring(0,2));
		}
		String printsec = printsec_part1 + " "+printsec_part2;
		return printsec;
	}

}
