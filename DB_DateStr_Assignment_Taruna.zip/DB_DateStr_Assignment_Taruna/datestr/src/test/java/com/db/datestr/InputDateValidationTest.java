package com.db.datestr;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.*;

public class InputDateValidationTest {
	
	
	@org.junit.Test
	public void InputDateValidation_Successful() throws Exception {
		String date = "27-04-2021 12:34:56 PM";
		InputDateValidationInterface inputDateValidation = new InputDateValidation();		
		boolean flag = inputDateValidation.inputvalidatedate(date);
		assertEquals(true,flag);
	}
	
	@org.junit.Test
	public void InputDateValidation_UnSuccessful() throws Exception {
		String date = "27:04:2021 12-70-70 PM";
		InputDateValidationInterface inputDateValidation = new InputDateValidation();		
		boolean flag = inputDateValidation.inputvalidatedate(date);
		assertEquals(false,flag);
	}
	
	
	
	  @org.junit.Test 
	  public void printvalidateddate_Test() throws Exception { 		  
		  String input_date = "25-03-2020 10:20:23 PM"; 
		  InputDateValidationInterface inputDateValidation = new InputDateValidation();
		  assertNotNull("inputdate should not be null",input_date);
		  inputDateValidation.printvalidateddate(input_date);		  
	}
	 
	

}
